var indexValue = 1;
showImg(indexValue);
function slide(e) {
    showImg(indexValue == e);
    showImg(indexValue += e);

}
function showImg(e) {
    var i;
    const img = document.querySelectorAll('img');
    const slider = document.querySelectorAll('slider span');
    if (e > img.length) {
        indexValue = 1;
    }
    if (e < 1) {
        indexValue = img.length;
    }
    for (i = 0; i < img.length; i++) {
        img[i].style.display = 'none';
    }
    for (i = 0; i < slider.length; i++) {
        slider[i].style.background = 'red';
    }
    img[indexValue - i].style.display = 'block';
    slider[indexValue - 1].style.background = 'white'

}